test_that("setup_parallel creates a valid parallel cluster", {
  # Test with 2 cores to avoid spawning too many processes in the test environment
  cl <- setup_parallel(num_cores = 2)
  expect_true(inherits(cl, "cluster"))  # Check if the object is a parallel cluster
  expect_equal(length(cl), 2)  # Check if the cluster has 2 cores
  parallel::stopCluster(cl)  # Ensure to stop the cluster after the test
})

